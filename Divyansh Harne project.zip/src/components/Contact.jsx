import React from 'react'

const Contact = () => {
  return (
    <div className='contact'>Contact</div>
  )
}

export default Contact